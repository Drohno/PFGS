/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Button */
    $(document).on("click", ".uib_w_6", function(evt)
    {
        //var postData = $(this).serialize();
        $.ajax({
                type:'POST',
                url:'http://www.appserv.hol.es/appservice.php',
                data: $("#formulario").serialize(),
                dataType: 'text',
                success: function (data) {
                    alert('conexion establecida');
                    //var obj = JSON.parse(data);
                    //alert(obj.resultat[1]);
                },
                error: function(xhr, textStatus, errorThrown, data){
                    console.log("xhr.status: " + xhr.status);
                    console.log("xhr.statusText: " + xhr.statusText);
                    console.log("xhr.readyState: " + xhr.readyState);
                    console.log("xhr.responseText: " + xhr.responseText);
                    console.log("errorThrown: " + errorThrown);
                    alert(JSON.stringify(data));
                }
            });
        evt.preventDefault();
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
